#include "easypr/train/train.h"

namespace easypr {

ITrain::ITrain() {}

ITrain::~ITrain() {}
}
