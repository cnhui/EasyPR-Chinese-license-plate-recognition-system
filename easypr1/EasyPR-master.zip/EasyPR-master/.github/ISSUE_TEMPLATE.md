**I'm submitting a ...**  (check one with "x")

```
[ ] bug report
[ ] help wanted
[ ] feature request
```

**Current behavior**



**Expected/desired behavior**



**Reproduction of the problem**

If the current behavior is a bug or you can illustrate your feature request better with an example, please provide the steps to reproduce.



**What is the expected behavior?**



**What is the motivation / use case for changing the behavior?**



**Please tell us about your environment:**

* **System:** CentOS

* **Compiler version/IDE:** gcc4.8

* **CMake version:** 3.5.1

* **OpenCV version:** [2.4.9 | 2.4.10 | 2.4.11 | 2.4.12 | 2.4.13 | 3.0 ALPHA | 3.0 BETA | 3.0 RC1 | 3.0 | 3.1 ]
